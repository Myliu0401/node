function xyz(exports,require,module,__filename, __dirname) {

    //---
    //中间的内容是我们写的nodejs的代码
    //---

    return module.exports;
}