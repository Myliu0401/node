//NodeJs的模块是运行在一个函数当中的。
require("./test.js");