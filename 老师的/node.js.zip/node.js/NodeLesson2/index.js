var test = require("./test.js");//返回一个模块对象

console.log(test.x);